import { loadSovendusPage } from "sovendus-integration-scripts";

loadSovendusPage();
