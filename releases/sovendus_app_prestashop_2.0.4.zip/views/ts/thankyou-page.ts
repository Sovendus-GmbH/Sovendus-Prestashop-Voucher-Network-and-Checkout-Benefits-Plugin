import { loadSovendusThankyouPage } from "sovendus-integration-scripts";

loadSovendusThankyouPage();
